package com.example.demo2.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo2.dto.UserResponse;
import com.example.demo2.entity.User;
import com.example.demo2.mapper.UserMapper;

@CrossOrigin
@RestController
@RequestMapping("/api")
public class UserController {

    @Autowired
    UserMapper userMapper;


    @RequestMapping("/login")
    public UserResponse login(@RequestParam("email") String email,
                        @RequestParam("passwd") String passwd ){

        User existingUser = userMapper.findByEmail(email);

        UserResponse userResponse = new UserResponse();
        if ((existingUser != null) && (passwd.equals(existingUser.getPwd()))) {
            userResponse.setUsername(existingUser.getUsername());
            userResponse.setId(existingUser.getId());
        } else {
            userResponse.setUsername("");
            userResponse.setId(-1);
        }

        return userResponse;

    }

}
