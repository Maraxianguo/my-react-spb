package com.example.demo2.mapper;

import org.apache.ibatis.annotations.Mapper;

import com.example.demo2.entity.User;

@Mapper
public interface UserMapper {

    User findByEmail(String email);

}
