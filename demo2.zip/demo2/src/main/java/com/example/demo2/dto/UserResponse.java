package com.example.demo2.dto;

import lombok.Data;

@Data
public class UserResponse {
    private int id;
    private String username;

}
